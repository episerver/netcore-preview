import React, { useEffect } from 'react';
import { ExposedDropdownMenu, TextField } from '@episerver/ui-framework';
// NETCORE
// How import CriteriaEditorProps ts interface? It is located in \netcore\CMSUI\EPiServer.VisitorGroups.Management.UI\clientResources\src\Models
// import { CriteriaEditorProps } from '../../../clientResources/src/Models/CriteriaEditorProps';
// const ProductInCartOrWishList = (props: CriteriaEditorProps) => {

const ProductInCartOrWishList = (props: any) => {

    const [localModelState, setLocalModelState] = React.useState({});

    useEffect(() => {
        let state = { ...props.settings };
        setLocalModelState(state);
    }, []);

    const emitValueChange = (newState: any) => {
        props.onValueChange(newState);
        setLocalModelState(newState);
    }

    return (
        <>
            <ExposedDropdownMenu
                outlined
                options={props && props.editorConfig.comparisonType.selectItems.map(item => {
                    return {
                        label: item.text,
                        value: item.value.toString()
                    }
                })}
                label={props && props.editorConfig.comparisonType.label}
                value={localModelState.comparisonType?.toString()}
                onValueChange={value => {
                    let newState = {...localModelState};
                    newState.comparisonType = value;

                    // The change requires us to reset the other inputs
                    newState.productName = '';
                    newState.category = '';
                    newState.property = '';
                    newState.propertyValue = '';

                    emitValueChange(newState);
                }}
            />


            {localModelState?.comparisonType === "Product" &&  
            <TextField
                style={{ marginLeft: '6px', marginRight: '6px' }}
                outlined
                defaultValue={localModelState.productName}
                required
                onChange={evt => {
                    let newState = { ...localModelState };
                    newState.productName = evt.currentTarget.value;
                    emitValueChange(newState);
                }}
            />
            }


            {localModelState?.comparisonType === "FromCategory" &&  
            <span style={{marginLeft: '6px'}}>
                <ExposedDropdownMenu
                    outlined
                    options={props && props.editorConfig.category.selectItems.map(item => {
                        return {
                            label: item.text,
                            value: item.value.toString()
                        }
                    })}
                    required
                    label={props && props.editorConfig.category.label}
                    value={localModelState.category?.toString()}
                    onValueChange={value => {
                        let newState = { ...localModelState };
                        newState.category = value;
                        emitValueChange(newState);
                    }}
                />
            </span>
            }


            {localModelState?.comparisonType === "HasPropertyAndValue" &&  
            <>
            
            <TextField
                style={{ marginLeft: '6px', marginRight: '6px' }}
                outlined
                defaultValue={localModelState.property}
                required
                label={props && props.editorConfig.property.label}
                onChange={evt => {
                    let newState = { ...localModelState };
                    newState.property = evt.currentTarget.value;
                    emitValueChange(newState);
                }}
            />

            <TextField
                style={{ marginLeft: '6px', marginRight: '6px' }}
                outlined
                defaultValue={localModelState.propertyValue}
                required
                label={props && props.editorConfig.propertyValue.label}
                onChange={evt => {
                    let newState = { ...localModelState };
                    newState.propertyValue = evt.currentTarget.value;
                    emitValueChange(newState);
                }}
            />
            </>
            }            
        </>
    )
}

export default ProductInCartOrWishList