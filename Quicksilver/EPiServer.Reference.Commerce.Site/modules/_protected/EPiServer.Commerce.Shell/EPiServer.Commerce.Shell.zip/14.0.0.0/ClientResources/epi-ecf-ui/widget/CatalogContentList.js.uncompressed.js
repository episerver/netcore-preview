require({cache:{
'url:epi-ecf-ui/widget/templates/CatalogContentList.html':"﻿<div class=\"epi-catalogContentList\">\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-cms/contentediting/StandardToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div class=\"epi-localToolbar epi-flatToolbar\">\r\n        <div class=\"epi-toolbarGroupContainer\">\r\n            <div class=\"epi-toolbarGroup epi-toolbarLeading\" data-dojo-attach-point=\"leadingNode\"></div>\r\n            <div class=\"epi-toolbarGroup epi-toolbarCenter\" data-dojo-attach-point=\"centerNode\"></div>\r\n            <div class=\"epi-toolbarGroup epi-toolbarTrailing\" data-dojo-attach-point=\"trailingNode\">\r\n                <div class=\"dijit dijitToolbar dijitContainer\">\r\n                    <label for=\"markets\">${resources.market}</label>\r\n                    <select name=\"markets\" data-dojo-type=\"epi-ecf-ui/widget/MarketSelector\" data-dojo-attach-point=\"marketSelector\" data-dojo-attach-event='onChange: _onMarketChanged'\r\n                        class=\"epi-chromelessSelect epi-flatSelect epi-button--right-spacer\"></select>\r\n                    <div class=\"dijit dijitToolbar epi-groupedButtonContainer dijitInline\">\r\n                        <button data-dojo-type=\"epi-ecf-ui/widget/CommandToggleButton\" data-dojo-attach-event=\"onClick: toggleThumbnails\" data-dojo-attach-point=\"listview\"\r\n                            class=\"epi-flat epi-chromeless dijitButton\" data-dojo-props=\"iconClass: 'epi-iconList', showLabel: false, title: '${resources.switchbuttons.listview}'\">\r\n                        </button><button data-dojo-type=\"epi-ecf-ui/widget/CommandToggleButton\" data-dojo-attach-event=\"onClick:toggleThumbnails\"\r\n                            data-dojo-attach-point=\"thumbnail\" checked=\"true\" class=\"epi-flat epi-chromeless dijitButton\" data-dojo-props=\"iconClass: 'epi-iconThumbnails', showLabel: false, title: '${resources.switchbuttons.thumbnail}'\">\r\n                        </button>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"notificationBar\" data-dojo-type=\"epi-cms/contentediting/NotificationBar\" data-dojo-props=\"region:'top'\"></div>\r\n    <div class=\"epi-editor-overlay epi-grid--with-container\" data-dojo-attach-point=\"overlayDnd\">\r\n        <div data-dojo-attach-point=\"gridNode\" class=\"epi-plain-grid epi-plain-grid--small-header-font epi-dgrid-multiselect\"></div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/CatalogContentList", [
    // Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/json",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/Deferred",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/dom-style",
    "dojo/keys",
    "dojo/topic",
    "dojo/when",

    //Dgrid
    "dgrid/selector",
    "dgrid/tree",

    // Epi Shell
    "epi",
    "epi/shell/dgrid/util/misc",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/dialog/Alert",
    "epi/string",

    // Epi CMS
    "epi-cms/core/ContentReference",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/NotificationBar",
    "epi-cms/dgrid/formatters",

    // Epi Commerce
    "./_ContentSecurableList",
    "./_FullHeightContentMixin",
    "./_ToggleCutSelectionMixin",
    "./viewmodel/CatalogContentListViewModel",
    "./CommandToolbar",
    "./CommandButton",
    "./CommandToggleButton",
    "./MarketSelector",
    "./SimpleViewNotification",
    "../contentediting/ModelSupport",

    // Resources
    "dojo/text!./templates/CatalogContentList.html",
    "epi/i18n!epi/cms/nls/commerce.widget.cataloglist",
    "epi/i18n!epi/cms/nls/commerce.widget.catalogcontentlist"
], function (
    // Dojo
    array,
    declare,
    json,
    lang,
    aspect,
    Deferred,
    domClass,
    domConstruct,
    domStyle,
    keys,
    topic,
    when,

    //Dgrid
    selector,
    tree,

    // Epi Shell
    epi,
    misc,
    TypeDescriptorManager,
    _FocusableMixin,
    Alert,
    epiString,

    // Epi CMS
    ContentReference,
    ContentActionSupport,
    NotificationBar,
    formatters,

    // Epi Commerce
    _ContentSecurableList,
    _FullHeightContentMixin,
    _ToggleCutSelectionMixin,
    CatalogContentListViewModel,
    CommandToolbar,
    CommandButton,
    CommandToggleButton,
    MarketSelector,
    SimpleViewNotification,
    ModelSupport,

    // Resources
    template,
    res,
    catalogContentListResources) {

        return declare([_ContentSecurableList, _FocusableMixin, _FullHeightContentMixin, _ToggleCutSelectionMixin], {
            // summary:
            //    Lists the content of catalogs and categories.
            // description:
            //    This is the widget that lists the content of catalogs and categories.
            // tags:
            //    public
            resources: catalogContentListResources,

            gridOverlayClass: "epi-grid-dnd-overlay",

            templateString: template,

            _multipleSelectionClassName: "epi-dgrid-multiselect--multiple-selection",

            storeKeyName: "epi.cms.content.light",

            _noDataMessage: catalogContentListResources.nodatamessage,

            _simpleViewNotification: null,

            // contextChangeEvent: [public] String
            //      Setup so that the context change events are not configured in the base class.
            contextChangeEvent: "",

            commandToolbar: null,

            postCreate: function () {
                this.inherited(arguments);

                // Watching instead of binding since we need the old value as well.
                this.own(
                    this.model.watch("sortMode", this._onSortModeChanged.bind(this))
                );

                if (!this._simpleViewNotification) {
                    this._simpleViewNotification = new SimpleViewNotification();

                    this.own(
                        this._simpleViewNotification.watch("notification", this._defaultNotificationWatchHandler.bind(this))
                    );
                }
            },

            postMixInProperties: function () {
                this.inherited(arguments);
                this._modifyStoreToHandleDgridTree();

                lang.mixin(this.defaultGridMixin.dndParams, {
                    selfAccept: true,
                    copyOnly: false,
                    accept: [ModelSupport.contentTypeIdentifier.entryContentBase, ModelSupport.contentTypeIdentifier.nodeContent]
                });
            },

            _defaultNotificationWatchHandler: function (/*String*/name, /*Object*/oldValue, /*Object*/newValue) {
                // summary:
                //      Add/remove notification to/from the notification bar.
                // tags:
                //      private

                if (oldValue) {
                    this.notificationBar.remove(oldValue);
                }

                if (newValue && newValue.content) {
                    this.notificationBar.add(newValue);
                }

                this.layout();
            },

            _modifyStoreToHandleDgridTree: function () {
                // summary:
                //      getChildren and mayHaveChildren are needed on the store
                //      for dgrids tree module to work.
                // tags:
                //      private

                var self = this;
                this.store = lang.mixin(this.store, {
                    getChildren: function (parent, options) {
                        var originalQuery = self.grid.get("query");
                        var queryOptions = self._getQueryOptions(parent.contentLink, false, false, originalQuery);
                        return this.query(queryOptions.queryParameters, queryOptions.queryOptions);
                    },
                    mayHaveChildren: function (parent) {
                        // This is only called by dgrids tree module and therefore we only want to do it on entries.
                        return parent.hasChildren
                            && TypeDescriptorManager.isBaseTypeIdentifier(parent.typeIdentifier, ModelSupport.contentTypeIdentifier.entryContentBase);
                    }
                });
            },

            startup: function () {
                // summary:
                //      Adds the breadcrumb widget to the top of the list widget.
                // tags:
                //      protected
                this.inherited(arguments);

                // Only the selection column should update selections.
                this.grid.set("selectionMode", "none");

                var dndSource = this.grid.dndSource;

                //override function so that nothing is appended to the dom after a mouseup event is completed.
                dndSource.insertNodes = function () { };

                // Making the dragsource handle multiple selects
                dndSource.singular = false;
                // We need to allow nested selections to be able to dnd expanded items.
                dndSource.allowNested = true;

                this.own(
                    topic.subscribe("relationChanged", function () {
                        this.grid.refresh();
                    }.bind(this)),
                    topic.subscribe("catalogItemsMoved", function () {
                        // Clear the selection, clipboard and refresh the grid when a catalog item has been moved.
                        this.grid.clearSelection();
                        this.updateSelection();
                    }.bind(this)),
                    topic.subscribe("catalogContentDeleted", function (deletedItems) {

                        var isDeletedItemInGrid = array.some(deletedItems, function (item) {
                            var row = this.grid.row(item);

                            // We know that the item exists in the grid if the row has a contextId.
                            return row && row.data && row.data.contextId;
                        }.bind(this));

                        if (isDeletedItemInGrid) {
                            this.grid.clearSelection();
                            this.updateSelection();
                            this.grid.refresh();
                        }
                    }.bind(this)),
                    topic.subscribe("itemsPasted", function () {
                        this.grid.refresh();
                    }.bind(this)),
                    aspect.after(dndSource, "onDndStart", function (source, nodes) {
                        var accepted = dndSource.accept && dndSource.checkAcceptance(source, nodes);
                        domClass[accepted ? "add" : "remove"](this.overlayDnd, this.gridOverlayClass);
                    }.bind(this), true),
                    this.model.on("onMoveUp", this._sortItemUpwards.bind(this)),
                    this.model.on("onMoveDown", this._sortItemDownwards.bind(this)),
                    aspect.after(this.grid.dndSource, "onDropData", this._onDndDrop.bind(this), true)
                );

                // Grid can handle these, no need to "own" them.
                this.grid.on("dgrid-rowcopy", this._onRowCopy.bind(this));
                this.grid.on("dgrid-rowcut", this._onRowCut.bind(this));
                this.grid.on("dgrid-rowpaste", this._onRowPaste.bind(this));
                this.grid.addKeyHandler(keys.ENTER, this._onChangeContext.bind(this));
                this.grid.addKeyHandler(keys.SPACE, function (evt) {
                    var row = this.grid.row(evt);
                    if (this.grid.isSelected(row)) {
                        this.grid.deselect(row);
                    } else {
                        this.grid.select(row);
                    }
                }.bind(this));
            },

            _onRowCopy: function () {
                this.model.getCommand("copy").execute();
            },

            _onRowCut: function () {
                this.model.getCommand("cut").execute();
            },

            _onRowPaste: function () {
                this.model.getCommand("pasteOnContext").execute();
            },

            toggleThumbnails: function () {
                this.model._commandRegistry.toggleThumbnails.command.execute();
                var showThumbnails = this.model.get("showThumbnails");

                this.thumbnail.set("checked", showThumbnails);
                this.listview.set("checked", !showThumbnails);

                domClass.toggle(this.grid.columns.thumbnail, "dgrid-header-hidden");
                domClass.toggle(this.grid.columns.thumbnail.headerNode, "dgrid-header-hidden");

                this._refreshView();
            },

            buildRendering: function () {
                this.inherited(arguments);

                var commands = this.model.getSelectionCommands();
                this.commandToolbar = new CommandToolbar(commands);
                this.own(this.commandToolbar);
                domConstruct.place(this.commandToolbar.domNode, this.leadingNode);

                // listen for command toolbar's layout changed, to resize children (grid)
                this.own(aspect.after(this.commandToolbar, "layout", function () {
                    this.resize();
                }.bind(this)));
            },

            resize: function () {
                // summary:
                //		Resize this widget to the given dimensions.
                // tags:
                //		protected

                this.inherited(arguments);

                if (this.grid) {
                    this.grid.resize();
                    // make the content 100% height its container
                    this._setHeight(this.grid.domNode);
                }
            },

            _onRowClick: function (e) {
                this._onChangeContext(e);
            },

            _toggleColumnHeaderClickable: function () {
                // summary:
                //      Sets CSS "pointer-events" property for each column header dom node in order to disable click on it when sort mode is TRUE.
                //      Otherwise, remove this CSS property to restore original click feature.
                //      For more information, please refer: https://developer.mozilla.org/en/docs/Web/CSS/pointer-events?v=example
                // tags:
                //      private

                domClass.toggle(this.grid.domNode, "epi-dgrid--sort-mode", this.model.get("sortMode"));
            },

            setupEvents: function () {
                this.inherited(arguments);
                this.own(this.grid.on("dgrid-deselect", this.updateSelection.bind(this)));
                this.own(this.grid.on(".epi-iconContextMenu:click", this.onContextMenuClick.bind(this)));

                for (var columnName in this.getColumnSettings()) {
                    if (columnName === "checkbox" || columnName === "expando") {
                        continue;
                    }
                    this.own(this.grid.on(".dgrid-cell.dgrid-column-" + columnName + ":click", this._onRowClick.bind(this)));
                }

                var self = this;
                this.own(
                    aspect.around(this.grid.dndSource, "checkAcceptance", function (originalMethod) {
                        return function (source, nodes) {
                            if (source !== self.grid.dndSource || !self.model.sortMode) {
                                return false;
                            }

                            return originalMethod.call(self.grid.dndSource, arguments);
                        };
                    })
                );
            },

            updateSelection: function () {
                var selection = [];
                for (var id in this.grid.selection) {
                    var row = this.grid.row(id);
                    lang.mixin(row.data, { rowId: id });
                    selection.push(row.data);
                }

                this.model.updateSelection(selection);
                this._removeContextMenuWhenRowIsSelected();
            },

            getListSettings: function () {
                // summary:
                //      Override to specify the settings used to create the list.
                // tags:
                //      protected

                var settings = this.inherited(arguments);

                return lang.mixin(settings, { cellNavigation: false, noDataMessage: this._noDataMessage });
            },

            _onSelect: function (e) {
                // summary:
                //		Extends _onSelect to remove context menu when multiple rows are selected
                //      and expands rows that can be expanded.
                // tags:
                //		protected override

                this.inherited(arguments);

                this.updateSelection();
            },

            _removeContextMenuWhenRowIsSelected: function () {
                // summary:
                //		Removes context menu when multiple rows are selected. If a single row is selected the context menu is not removed.
                // tags:
                //		protected

                if (this.model.numSelectedRows > 1) {
                    domClass.add(this.grid.contentNode, this._multipleSelectionClassName);
                } else {
                    domClass.remove(this.grid.contentNode, this._multipleSelectionClassName);
                }
            },

            onContextMenuClick: function (e) {
                // we have to update the commands even though we're technically not selecting this row.
                // Selection should only be done in the checkboxes column.
                var row = this.grid.row(e);
                var data = lang.mixin(row.data, { rowId: row.id });
                this.model.set("model", { data: [data] });

                // Display arrow for menu item whenever have sub menu in context menu
                array.forEach(this.grid.contextMenu.getChildren(), function (menu, i) {
                    if (menu.arrowWrapper && menu.popup) {
                        domStyle.set(menu.arrowWrapper, "visibility", "");
                    }
                });

                this.grid.clearSelection();
                this.grid.select(row);

                var parameter = this._createCommandAvailabilityParameter(row);

                this.model.setCommandAvailability(parameter);
            },

            _createCommandAvailabilityParameter: function (row) {
                // summary:
                //      Creates a parameter object used for determining a Command's
                //      CanExecute and Availability values.
                // tags:
                //      private
                var previousSibling = this.grid.row(row.element["previousSibling"]);
                var nextSibling = this.grid.row(row.element["nextSibling"]);
                var parameter = {
                    isFirstItem: !previousSibling,
                    isLastItem: !nextSibling
                };

                return parameter;
            },

            createModel: function () {
                return new CatalogContentListViewModel();
            },

            updateView: function (data, context) {
                // summary:
                //      This is called when the context has changed.
                // tags:
                //      public override

                this._simpleViewNotification.updateNotification(context);
                when(this.store.get(context.id), function (contentData) {
                    this.toolbar.update({
                        currentContext: context,
                        viewConfigurations: {
                            availableViews: data.availableViews,
                            viewName: data.viewName
                        },
                        contentData: contentData
                    });

                    this.fetchData(context);
                }.bind(this));
            },

            fetchData: function (context) {
                // summary:
                //		Fetches data by setting a query on the grid. A getrelations query will be performed on the store.
                // tags:
                //		protected

                this._setGridQuery(context);

                // Disable sort mode when the context is catalog content
                var sortModeCommand = this.model.getCommand("toggleSortMode");
                if (sortModeCommand) {
                    var isCatalogContext = TypeDescriptorManager.isBaseTypeIdentifier(context.dataType, ModelSupport.contentTypeIdentifier.catalogContent);
                    sortModeCommand.set("canExecute", !isCatalogContext);

                    // Reset all commands visibility if the sort mode is enabled
                    if (isCatalogContext && this.model.get("sortMode")) {
                        this.model.set("sortMode", false);
                    }
                }

                // Navigate content tree use content without work id. So should set selection data with context id in unspecific version reference.
                var contextLink = new ContentReference(context.id).createVersionUnspecificReference().toString();

                when(this.store.get(contextLink), function (contentData) {
                    this.updateSelection();

                    var pasteOnContextCommand = this.model.getCommand("pasteOnContext");
                    pasteOnContextCommand.selection.set("data", [{ type: "epi.cms.contentdata", data: contentData }]);
                }.bind(this));
            },

            _setGridQuery: function (context) {
                if (!context) {
                    return;
                }
                var supportSort = !!context.capabilities && !!context.capabilities.sortChildren;
                var simplified = !supportSort;
                var onlyTopLevel = supportSort;
                var queryOptions = this._getQueryOptions(context.id, simplified, onlyTopLevel);

                this.grid.set("query", queryOptions.queryParameters, queryOptions.queryOptions);
            },

            _getQueryOptions: function (id, simplified, onlyTopLevelChildren, originalQuery) {
                var currentCategory = id;
                if (originalQuery) {
                    currentCategory = originalQuery.currentCategory;
                }
                return {
                    queryOptions: { ignore: ["query"], parentId: id, sort: (!simplified && !!onlyTopLevelChildren) ? [{ attribute: "typeSortIndex" }] : null },
                    queryParameters: {
                        referenceId: id,
                        query: "getchildren",
                        market: this.marketSelector ? this.marketSelector.value : null,
                        includeProperties: true,
                        allLanguages: true,
                        toplevel: onlyTopLevelChildren,
                        currentCategory: currentCategory,
                        simplified: simplified,
                        sortMode: this.model.get("sortMode")
                    }
                };
            },

            getColumnSettings: function () {
                // summary:
                //		Returns an object with the settings for the columns of the grid.
                // tags:
                //		private

                var columnSettings = this.inherited(arguments) || {};

                return lang.mixin({
                    expando: tree({
                        label: "",
                        sortable: false,
                        allowDuplicates: true,
                        renderExpando: function (level, hasChildren, expanded, object) {
                            // summary:
                            //      We override the default expando rendering to get rid of the
                            //      default indentation.

                            var node = domConstruct.create("div");
                            if (this.model.get("sortMode")) {
                                domClass.add(node, "dijitInline epi-iconDnD");
                            }
                            else {
                                //"dgrid-expando-icon" is needed for click events
                                domClass.add(node, "dgrid-expando-icon");
                                if (hasChildren) {
                                    domClass.add(node, "dgrid-expando-arrow");
                                }
                            }
                            node.innerHTML = "&nbsp;";
                            return node;
                        }.bind(this)
                    }),
                    checkbox: selector({
                        label: "",
                        selectorType: "checkbox"
                    }),
                    thumbnail: {
                        renderHeaderCell: function (node) { },
                        get: function (object) {
                            return this.model.showThumbnails ? object.properties.thumbnail : null;
                        }.bind(this),
                        formatter: formatters.thumbnail,
                        sortable: false
                    },
                    /* Name of column used in sorting - use typeSortIndex property, not typeIdentifier */
                    typeSortIndex: {
                        label: "",
                        get: function (object) {
                            return object.typeIdentifier;
                        },
                        formatter: function (typeIdentifier, additionalClass) {
                            return formatters.contentIcon(typeIdentifier, additionalClass);
                        }
                    },
                    name: {
                        get: function (object) {
                            if (object.properties.displayName) {
                                return object.properties.displayName;
                            }
                            return object.name;
                        },
                        label: epi.resources.header.name,
                        className: "epi-columnWide"
                    },
                    code: {
                        get: function (object) {
                            return object.properties.code;
                        },
                        label: res.code
                    },
                    price: {
                        get: function (object) {
                            return object.properties.price;
                        },
                        label: res.price,
                        sortable: false
                    },
                    stock: {
                        get: function (object) {
                            return { count: object.properties.inStockQuantity, status: object.properties.inStockStatus };
                        },
                        label: res.stock,
                        formatter: this._getStockElement,
                        sortable: false
                    },
                    isPendingPublish: {
                        get: function (object) {
                            return object.status === ContentActionSupport.versionStatus.Published;
                        },
                        label: res.active,
                        formatter: formatters.friendlyBoolean
                    },
                    startPublish: {
                        get: function (object) {
                            return object.properties.startPublish;
                        },
                        label: res.availablefrom,
                        formatter: this._localizedDateAndSecondaryText
                    },
                    stopPublish: {
                        get: function (object) {
                            return object.properties.stopPublish;
                        },
                        label: epi.resources.header.expires,
                        formatter: this._localizedDateAndSecondaryText
                    },
                    metaClassName: {
                        get: function (object) {
                            return object.properties.metaClassName;
                        },
                        label: res.producttype,
                        formatter: formatters.secondaryText
                    }
                }, columnSettings);
            },

            _getStockElement: function (stock) {
                if (stock.count === undefined || stock.count === null) {
                    return "";
                }

                var stateCssClass = "epi-stock-" + stock.status;

                return '<span class="epi-stock ' + stateCssClass + '">' + stock.count + misc.icon('epi-iconBoxes') + '</span>';
            },

            _localizedDateAndSecondaryText: function (value) {
                return formatters.secondaryText(formatters.localizedDate(value), true);
            },

            _onMarketChanged: function () {
                if (!this.grid) return;

                when(this.getCurrentContext()).then(function (context) {
                    this._setGridQuery(context);
                }.bind(this));
            },

            _onSortModeChanged: function (name, oldValue, newValue) {
                this._updateMarketSelector(newValue);
                this._toggleColumnHeaderClickable();
                when(this.getCurrentContext()).then(function (context) {
                    this._setGridQuery(context);
                }.bind(this));
            },

            _updateMarketSelector: function (sortModeActive) {
                var currentSelection = this.marketSelector.get("value");
                var originalSelection = this.model.get("originalMarketSelection");

                this.marketSelector.set("readOnly", sortModeActive);

                if ((currentSelection === "ALL" && sortModeActive) ||   // We are entering sort mode and the selection is already "ALL", no need to do anything.
                    (originalSelection === "ALL" && !sortModeActive)) { // We are leaving sort mode and the original selection is "ALL", no need to reset anything.
                    return;
                }

                if (sortModeActive) {
                    this.model.set("originalMarketSelection", currentSelection);
                    this.marketSelector.set("value", "ALL");
                } else {
                    this.marketSelector.set("value", originalSelection);
                }
            },

            _sortItemUpwards: function () {
                // summary:
                //      Moves the grid's currently selected row one step up.
                // tags:
                //      Private
                this._moveSelectedItem(true);
            },

            _sortItemDownwards: function () {
                // summary:
                //      Moves the grid's currently selected row one step down.
                // tags:
                //      private
                this._moveSelectedItem(false);
            },

            _moveSelectedItem: function (isUpward) {
                // summary:
                //      Moves the grid's currently selected row either one step down or one step up.
                // tags:
                //      private
                var currentRow = this.grid.row(this.selection[0].rowId);
                var nextSibling = currentRow.element[isUpward ? "previousSibling" : "nextSibling"];

                if (!nextSibling) {
                    return;
                }

                var targetItem = this.grid.row(nextSibling).data;

                return when(this.model.moveItem(
                    { contentLink: this.selection[0].contentLink },
                    targetItem, isUpward
                )).then(this._refreshView.bind(this), this._errorCallback.bind(this));
            },

            _errorCallback: function (error) {
                var parseRepsonseText = function (responseData) {
                    if (typeof responseData === "string") {
                        return json.fromJson(responseData);
                    }

                    return "";
                };

                var alertDialog = new Alert({
                    heading: catalogContentListResources.sorting.error,
                    description: parseRepsonseText(error.responseText) || epiString.toHTML(error.message),
                    destroyOnHide: true
                });

                alertDialog.show();

                this.grid.refresh();
            },

            _onDndDrop: function (dndData, source, nodes, copy) {
                var moveItem = function (itemData, targetItemData, moveBefore) {
                    return this.model.moveItem(
                        itemData,
                        targetItemData,
                        moveBefore);
                };

                // Internal move, don't sort when dropping from outside the grid.
                if (this.grid.dndSource === source) {

                    var promiseChain = new Deferred();
                    promiseChain.resolve(); // This is needed to to initiate the chain of move operations.

                    var targetItemData = this.grid.dndSource.current && this.grid.dndSource.getItem(this.grid.dndSource.current.id).data;
                    var moveBefore = this.grid.dndSource.before;

                    if (!moveBefore) {
                        nodes = nodes.reverse();
                    }

                    for (var i = 0; i < nodes.length; i++) {
                        var itemData = this.grid.dndSource.getItem(nodes[i].id).data;

                        if (!itemData.properties.isLinkedToCurrentCategory) {
                            continue;
                        }

                        promiseChain = promiseChain.then(lang.partial(moveItem.bind(this), itemData, targetItemData, moveBefore));
                    }

                    promiseChain.then(this._refreshView.bind(this), this._errorCallback.bind(this));
                }
            },

            _refreshView: function () {
                // summary:
                //      Refreshes the current view and its data.
                // tags:
                //      private
                this.grid.refresh();
            }
        });
    });