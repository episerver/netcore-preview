define([
    "epi-addon-tinymce/Editor",
    "epi-addon-tinymce/EditorWrapper",
    "epi-addon-tinymce/OnPageEditor",
    "epi-addon-tinymce/Overlay",
    "epi-addon-tinymce/tinymce-loader"
], 1);
